package com.example.exceluploadmaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelUploadMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelUploadMasterApplication.class, args);
	}

}
